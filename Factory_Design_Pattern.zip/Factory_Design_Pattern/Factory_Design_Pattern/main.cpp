#include<iostream>
#include<chrono>
#include<thread>
using namespace std;
#include"ToyFactory.cpp"
int main()
{
	//client code starts
	int type;
	while (1)
	{
		cout << endl << "Enter Your Choice:\n1.car\n2.bike\n3.plane\nPress 4 to Exit!!\n Your Choice:";
		cin >> type;
		cout << "\n";
		if (!type)
			break;
		Toy *toy = ToyFactory::creaetToy(type);
		if (toy)
		{
			toy->showProduct();
			delete toy;
		}
	}
	cout << "Thanks for your Time\n";
	std::this_thread::sleep_for(chrono::seconds(2));
	cout << "Bye!!\n";
	std::this_thread::sleep_for(chrono::seconds(2));
	return 0;

}