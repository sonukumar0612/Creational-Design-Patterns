#include"Objects.cpp"

class ToyFactory
{
public:
	static Toy * creaetToy(int type)
	{
		Toy *toy = NULL;
		switch (type)
		{
			case 1: {
				toy = new Car();
				break;
			}
			case 2: {
				toy = new Bike();
				break;
			}
			case 3: {
				toy = new Plane();
				break;
			}
			default:
				cout << "\nYour Input is wrong. Re enter your choice\n";
				return NULL;
		}
		toy->applyLabel();
		toy->assembleParts();
		toy->combineParts();
		toy->prepareParts();
		return toy;
	}
};