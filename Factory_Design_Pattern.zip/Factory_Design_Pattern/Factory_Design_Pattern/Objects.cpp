#include"Toy.h"
#include<iostream>
using namespace std;

class Car :public Toy
{
public:
	void prepareParts()
	{
		cout << "PrepareParts of Car Class\n";
	}
	void combineParts()
	{
		cout << "CombineParts of Car Class\n";
	}
	void assembleParts()
	{
		cout << "AssembleParts of Car Class\n";
	}
	void applyLabel()
	{
		cout << "ApplyLabel of Car Class\n";
		name = "Car";
		price = 99999.99;
	}
	void showProduct()
	{
		cout << "\nName is " << name << " and price is " << price << endl;
	}
};
class Bike :public Toy
{
public:
	void prepareParts()
	{
		cout << "PrepareParts of Bike Class\n";
	}
	void combineParts()
	{
		cout << "CombineParts of Bike Class\n";
	}
	void assembleParts()
	{
		cout << "AssembleParts of Bike Class\n";
	}
	void applyLabel()
	{
		cout << "ApplyLabel of Bike Class\n";
		name = "Bike";
		price = 88888.88;
	}
	void showProduct()
	{
		cout << "\nName is " << name << " and price is " << price << endl;
	}
};

class Plane :public Toy
{
public:
	void prepareParts()
	{
		cout << "PrepareParts of Plane Class\n";
	}
	void combineParts()
	{
		cout << "CombineParts of Plane Class\n";
	}
	void assembleParts()
	{
		cout << "AssembleParts of Plane Class\n";
	}
	void applyLabel()
	{
		cout << "ApplyLabel of Plane Class\n";
		name = "Plane";
		price = 100000000.99;
	}
	void showProduct()
	{
		cout << "\nName is " << name << " and price is " << price << endl;
	}
};