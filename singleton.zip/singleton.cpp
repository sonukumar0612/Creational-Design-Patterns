#include<iostream>
using namespace std;

class GameSetting
{
    static GameSetting * _instance;
    int _brightness;
    int _height;
    int _width;
    GameSetting() : _brightness{75},_height(1920),_width(1080){}
public:
    static GameSetting * getInstance()
    {
        if(_instance == NULL)
            _instance = new GameSetting();
        return _instance;
    }
    void setHeight(int height){_height=height;}
    void setWidth(int width){_width=width;}
    void setBrightness(int brightness){_brightness=brightness;}

    int getHeight(){return _height;}
    int getWidth(){return _width;}
    int getBrightness(){return _brightness;}

    void displaySettings()
    {
        cout << "Brightness = " << _brightness<<endl;
        cout << "Height = " << _height<<endl;
        cout << "Width = " << _width<<endl;
    }
};
GameSetting * GameSetting::_instance = NULL;

void someFunction()
{
    GameSetting *setting = GameSetting::getInstance();
    setting->displaySettings();
    cout << "address of instance id in someFunction: "<<setting << endl;
}

int main()
{
    GameSetting *setting = GameSetting::getInstance();
    setting->displaySettings();
    cout << "address of instance id : "<<setting << endl;
    someFunction();

    int *x = new(setting) int[8]{3,5,6,7,3,5,6,7};
    cout << "address of instance id : "<<setting << endl;
    delete setting;
    //someFunction();
        //setting->displaySettings();

}
